#ifndef __MSG_PARSER_H__
#define __MSG_PARSER_H__

void msg_parser_mqtt_data(const char* msg, unsigned int length);

#endif
